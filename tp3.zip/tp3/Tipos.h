#ifndef TIPOS_H_
#define TIPOS_H_

#include <iostream>

using namespace std;

typedef int Fecha;
typedef string Categoria;
typedef string Link;

#endif /* TIPOS_H_ */
