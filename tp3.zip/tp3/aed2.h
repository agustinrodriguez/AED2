
#ifndef AED2_INCLUDED_H
#define AED2_INCLUDED_H

#include "aed2/TiposBasicos.h"
#include "aed2/Arreglo.h"
#include "aed2/Lista.h"
#include "aed2/Vector.h"
#include "aed2/Dicc.h"
#include "aed2/Conj.h"
#include "aed2/ConjAcotado.h"
#include "test/test.h"

using namespace aed2;

#endif //AED2_INCLUDED_H
