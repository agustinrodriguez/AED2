#include "../DiccTrie.h"
#include <cstdlib>
#include "../aed2.h"
using namespace std;

int main(int, char**) {


    return 0;
}
